-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 31, 2021 alle 09:44
-- Versione del server: 10.4.14-MariaDB
-- Versione PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cookaroo`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `aggiunge_al_carrello`
--

CREATE TABLE `aggiunge_al_carrello` (
  `quantita` int(11) DEFAULT NULL,
  `cliente` char(36) DEFAULT NULL,
  `piatto` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `cliente`
--

CREATE TABLE `cliente` (
  `codicec` char(36) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `cognome` varchar(20) DEFAULT NULL,
  `telefono` char(13) DEFAULT NULL,
  `indirizzo` varchar(50) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `cliente`
--

INSERT INTO `cliente` (`codicec`, `username`, `password`, `nome`, `cognome`, `telefono`, `indirizzo`, `avatar`) VALUES
('71789bc2-c1e1-11eb-9f14-4ccc6a830121', 'liao@gmail.com', 'wvutsrq', 'Huadong', 'Liao', '3829028390', 'Via Littamodignani 65', 'null'),
('a29018ac-c1de-11eb-9f14-4ccc6a830121', 'example@gmail.com', 'szwkhlshweeaift', 'exam', 'ple', '33333333342', 'Via esempio 200', 'null');

-- --------------------------------------------------------

--
-- Struttura della tabella `commenta`
--

CREATE TABLE `commenta` (
  `commento` varchar(2000) DEFAULT NULL,
  `valutazione` int(11) DEFAULT NULL,
  `cliente` char(36) DEFAULT NULL,
  `piatto` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `commenta`
--

INSERT INTO `commenta` (`commento`, `valutazione`, `cliente`, `piatto`) VALUES
('Abbastanzo buono', 4, 'a29018ac-c1de-11eb-9f14-4ccc6a830121', '227c2bfa-c05b-11eb-86ca-4ccc6a830121'),
('Il mio sushi preferito', 5, 'a29018ac-c1de-11eb-9f14-4ccc6a830121', '7755c76c-c059-11eb-86ca-4ccc6a830121'),
('Decente, ma non consiglierei questo piatto', 3, 'a29018ac-c1de-11eb-9f14-4ccc6a830121', '7a39c152-c05a-11eb-86ca-4ccc6a830121'),
('Cosi Cosi', 2, '71789bc2-c1e1-11eb-9f14-4ccc6a830121', '7755c76c-c059-11eb-86ca-4ccc6a830121');

-- --------------------------------------------------------

--
-- Struttura della tabella `ingrediente`
--

CREATE TABLE `ingrediente` (
  `nome` varchar(20) DEFAULT NULL,
  `allergeni` tinyint(1) DEFAULT NULL,
  `piatto` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `ingrediente`
--

INSERT INTO `ingrediente` (`nome`, `allergeni`, `piatto`) VALUES
('Nori', 1, '227c2bfa-c05b-11eb-86ca-4ccc6a830121'),
('Riso', 0, '227c2bfa-c05b-11eb-86ca-4ccc6a830121'),
('Salmone crudo', 0, '227c2bfa-c05b-11eb-86ca-4ccc6a830121'),
('Avocado', 1, '7755c76c-c059-11eb-86ca-4ccc6a830121'),
('Salmone crudo', 0, '7755c76c-c059-11eb-86ca-4ccc6a830121'),
('Riso', 0, '7755c76c-c059-11eb-86ca-4ccc6a830121'),
('Riso', 0, '7a39c152-c05a-11eb-86ca-4ccc6a830121'),
('Salmone crudo', 0, '7a39c152-c05a-11eb-86ca-4ccc6a830121'),
('Spaghetti', 0, '88d0f0d5-c1af-11eb-86ca-4ccc6a830121'),
('Cozze', 1, '88d0f0d5-c1af-11eb-86ca-4ccc6a830121'),
('Pomodoro', 1, '88d0f0d5-c1af-11eb-86ca-4ccc6a830121'),
('Formaggio', 0, '88d0f0d5-c1af-11eb-86ca-4ccc6a830121'),
('Gamberi', 1, 'dcc0fcb4-c1b0-11eb-86ca-4ccc6a830121'),
('Cozze', 1, 'dcc0fcb4-c1b0-11eb-86ca-4ccc6a830121'),
('Alcol 4.5%', 0, '5c2f5591-c05c-11eb-86ca-4ccc6a830121'),
('Alcol 4.6%', 0, '7a1af67a-c05c-11eb-86ca-4ccc6a830121'),
('Alcol 4.6%', 0, 'b2a36471-c05c-11eb-86ca-4ccc6a830121'),
('Alcol 4.5%', 0, 'd70859d9-c05c-11eb-86ca-4ccc6a830121'),
('Cucumber', 0, 'f40fb686-c1b1-11eb-86ca-4ccc6a830121'),
('Arachidi', 1, 'f40fb686-c1b1-11eb-86ca-4ccc6a830121'),
('Spaghetti Cinese', 0, 'f40fb686-c1b1-11eb-86ca-4ccc6a830121');

-- --------------------------------------------------------

--
-- Struttura della tabella `ordine`
--

CREATE TABLE `ordine` (
  `codiceo` char(36) NOT NULL,
  `costototale` float DEFAULT NULL,
  `tempoconsegna` datetime DEFAULT NULL,
  `cliente` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `ordine`
--

INSERT INTO `ordine` (`codiceo`, `costototale`, `tempoconsegna`, `cliente`) VALUES
('8QY1VSIWCJ', 38.97, '2021-05-31 14:05:00', '71789bc2-c1e1-11eb-9f14-4ccc6a830121'),
('HKTVZZZUWD', 12.97, '2021-05-31 14:15:00', '71789bc2-c1e1-11eb-9f14-4ccc6a830121');

-- --------------------------------------------------------

--
-- Struttura della tabella `piatto`
--

CREATE TABLE `piatto` (
  `codicep` char(36) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `numerazione` int(11) DEFAULT NULL,
  `prezzo` float DEFAULT NULL,
  `avg_valutazione` float DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `tipologia` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `piatto`
--

INSERT INTO `piatto` (`codicep`, `nome`, `numerazione`, `prezzo`, `avg_valutazione`, `image`, `tipologia`) VALUES
('227c2bfa-c05b-11eb-86ca-4ccc6a830121', 'Hosomaki', 3, 3.49, 4, 'https://i.ibb.co/sKVhY2q/hosomaki-removebg-preview.png', 'Sushi'),
('5c2f5591-c05c-11eb-86ca-4ccc6a830121', 'Asahi', 4, 3.49, 0, 'https://i.ibb.co/x5byLYK/asahi-removebg-preview.png', 'Birra'),
('7755c76c-c059-11eb-86ca-4ccc6a830121', 'Uramaki', 1, 4.99, 3.5, 'https://i.ibb.co/5xxXmw4/california-removebg-preview.png', 'Sushi'),
('7a1af67a-c05c-11eb-86ca-4ccc6a830121', 'Heineken', 5, 3.99, 0, 'https://i.ibb.co/FHxqs01/heineken-removebg-preview.png', 'Birra'),
('7a39c152-c05a-11eb-86ca-4ccc6a830121', 'Nigiri', 2, 3.99, 3, 'https://i.ibb.co/P4kNKg2/salmonnigiri-removebg-preview.png', 'Sushi'),
('88d0f0d5-c1af-11eb-86ca-4ccc6a830121', 'Spaghetti FruttiMare', 8, 12.99, 0, 'https://i.ibb.co/XYTqdtt/spaghetti-ai-frutti-di-mare-removebg-preview.png', 'Spaghetti'),
('b2a36471-c05c-11eb-86ca-4ccc6a830121', 'Lager', 6, 4.49, 0, 'https://i.ibb.co/KsWZK94/lager-removebg-preview.png', 'Birra'),
('d70859d9-c05c-11eb-86ca-4ccc6a830121', 'Moretti', 7, 3.79, 0, 'https://i.ibb.co/C9Sq5bY/moretti-removebg-preview.png', 'Birra'),
('dcc0fcb4-c1b0-11eb-86ca-4ccc6a830121', 'FruttiMare misto', 9, 14.99, 0, 'https://i.ibb.co/ZS63rfn/OLYMPUS-DIGITAL-CAMERA.jpg', 'Seafood'),
('f40fb686-c1b1-11eb-86ca-4ccc6a830121', 'Spaghetti freddi', 10, 9.99, 0, 'https://i.ibb.co/tmDngRP/spaghettifreddi-removebg-preview.png', 'Spaghetti');

-- --------------------------------------------------------

--
-- Struttura della tabella `sedi`
--

CREATE TABLE `sedi` (
  `telefono` char(13) DEFAULT NULL,
  `indirizzo` varchar(100) DEFAULT NULL,
  `nazione` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `sedi`
--

INSERT INTO `sedi` (`telefono`, `indirizzo`, `nazione`) VALUES
('0284787893', 'Via esempio 77,20123, Milano', 'Italia'),
('0284122112', 'Via esempio 47,20013, Milano', 'Italia'),
('0284121142', 'Via esempio 12,00011, Roma', 'Italia'),
('0298234783', 'Via esempio 10,10111, Torino', 'Italia'),
('023444212', 'Via esempio 104,80121, Napoli', 'Italia'),
('339034728', 'Street given 19,10005, New York', 'America'),
('492031383', 'Street example 19,E17AW, London', 'England');

-- --------------------------------------------------------

--
-- Struttura della tabella `subordine`
--

CREATE TABLE `subordine` (
  `codiceso` char(36) NOT NULL,
  `quantita` int(11) DEFAULT NULL,
  `costosubtotale` float DEFAULT NULL,
  `ordine` char(36) DEFAULT NULL,
  `piatto` char(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `subordine`
--

INSERT INTO `subordine` (`codiceso`, `quantita`, `costosubtotale`, `ordine`, `piatto`) VALUES
('HVLOEAWGCJP', 3, 38.97, '8QY1VSIWCJ', '88d0f0d5-c1af-11eb-86ca-4ccc6a830121'),
('U1JX9N154YV', 1, 4.99, 'HKTVZZZUWD', '7755c76c-c059-11eb-86ca-4ccc6a830121'),
('V5NLZEOFL', 2, 7.98, 'HKTVZZZUWD', '7a39c152-c05a-11eb-86ca-4ccc6a830121');

-- --------------------------------------------------------

--
-- Struttura della tabella `tipologia`
--

CREATE TABLE `tipologia` (
  `nome` varchar(20) NOT NULL,
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `tipologia`
--

INSERT INTO `tipologia` (`nome`, `image`) VALUES
('Birra', 'https://i.ibb.co/7bBTB5x/birra-removebg-preview.png'),
('Dolce', 'https://i.ibb.co/YWNjKY8/dolce-removebg-preview.png'),
('Hamburger', 'https://i.ibb.co/Q9R85K2/hamburger-removebg-preview.png'),
('Pizza', 'https://i.ibb.co/s9b1j1L/pizza.png'),
('Seafood', 'https://i.ibb.co/rcVXFD2/seafood-removebg-preview.png'),
('Soda', 'https://i.ibb.co/vcdMF2N/soda-removebg-preview.png'),
('Spaghetti', 'https://i.ibb.co/j4Ph183/spaghetti-removebg-preview.png'),
('Sushi', 'https://i.ibb.co/gSjFNT7/sushi.png');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `aggiunge_al_carrello`
--
ALTER TABLE `aggiunge_al_carrello`
  ADD KEY `cliente` (`cliente`),
  ADD KEY `piatto` (`piatto`);

--
-- Indici per le tabelle `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`codicec`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indici per le tabelle `commenta`
--
ALTER TABLE `commenta`
  ADD KEY `cliente` (`cliente`),
  ADD KEY `piatto` (`piatto`);

--
-- Indici per le tabelle `ingrediente`
--
ALTER TABLE `ingrediente`
  ADD KEY `piatto` (`piatto`);

--
-- Indici per le tabelle `ordine`
--
ALTER TABLE `ordine`
  ADD PRIMARY KEY (`codiceo`),
  ADD KEY `cliente` (`cliente`);

--
-- Indici per le tabelle `piatto`
--
ALTER TABLE `piatto`
  ADD PRIMARY KEY (`codicep`),
  ADD UNIQUE KEY `numerazione` (`numerazione`),
  ADD KEY `tipologia` (`tipologia`);

--
-- Indici per le tabelle `subordine`
--
ALTER TABLE `subordine`
  ADD PRIMARY KEY (`codiceso`),
  ADD KEY `ordine` (`ordine`),
  ADD KEY `piatto` (`piatto`);

--
-- Indici per le tabelle `tipologia`
--
ALTER TABLE `tipologia`
  ADD PRIMARY KEY (`nome`);

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `aggiunge_al_carrello`
--
ALTER TABLE `aggiunge_al_carrello`
  ADD CONSTRAINT `aggiunge_al_carrello_ibfk_1` FOREIGN KEY (`cliente`) REFERENCES `cliente` (`codicec`),
  ADD CONSTRAINT `aggiunge_al_carrello_ibfk_2` FOREIGN KEY (`piatto`) REFERENCES `piatto` (`codicep`) ON DELETE CASCADE;

--
-- Limiti per la tabella `commenta`
--
ALTER TABLE `commenta`
  ADD CONSTRAINT `commenta_ibfk_1` FOREIGN KEY (`cliente`) REFERENCES `cliente` (`codicec`),
  ADD CONSTRAINT `commenta_ibfk_2` FOREIGN KEY (`piatto`) REFERENCES `piatto` (`codicep`) ON DELETE SET NULL;

--
-- Limiti per la tabella `ingrediente`
--
ALTER TABLE `ingrediente`
  ADD CONSTRAINT `ingrediente_ibfk_1` FOREIGN KEY (`piatto`) REFERENCES `piatto` (`codicep`) ON DELETE CASCADE;

--
-- Limiti per la tabella `ordine`
--
ALTER TABLE `ordine`
  ADD CONSTRAINT `ordine_ibfk_1` FOREIGN KEY (`cliente`) REFERENCES `cliente` (`codicec`);

--
-- Limiti per la tabella `piatto`
--
ALTER TABLE `piatto`
  ADD CONSTRAINT `piatto_ibfk_1` FOREIGN KEY (`tipologia`) REFERENCES `tipologia` (`nome`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `subordine`
--
ALTER TABLE `subordine`
  ADD CONSTRAINT `subordine_ibfk_1` FOREIGN KEY (`ordine`) REFERENCES `ordine` (`codiceo`),
  ADD CONSTRAINT `subordine_ibfk_2` FOREIGN KEY (`piatto`) REFERENCES `piatto` (`codicep`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
